k, e, m, s = map(int, input().split())
print(k >= 90 and e > 80 and m >85 and s >=80)