# 1번 심사
x = list(input().split())
x = x[0:-5]
x = print(tuple(x))

# 2번 심사
a = input()
b = input()
print(a[::2] + b[1::2])
