a = int(input())
b = tuple(range(-10,10,a))
print(b)