a = input().split()
b = list(map(float, input().split()))
c = dict(zip(a,b))
print(c)
a
b
c