# 1 '.'을 기준으로 구분하는 방법
# 2
files = input().split()

lambda files : split(.) if  len(files) >


files.split()
files3 = str(files)
files3.index('.')

files3{0:03d}.fomat(34)
'%03d' % files[1:]

files3[1:]

files
# .format의 '.'으로 나눈 후 첫번째[0]가 1이면 00을 붙이고, .의 인덱스가 2면 00을 붙인다.

print(list(map(lambda x: "{:0>3}.{}".format(x.split('.')[0],x.split('.')[1]),files)))


